package com.bean;

public class SearchService {
private String centerName="empty";
private String centerType="empty";
private String landmark="empty";
private String bookedService;
private String rejection="Book the service to know booking status";
public String getCenterName() {
	return centerName;
}
public void setCenterName(String centerName) {
	this.centerName = centerName;
}
public String getCenterType() {
	return centerType;
}
public void setCenterType(String centerType) {
	this.centerType = centerType;
}
public String getLandmark() {
	return landmark;
}
public void setLandmark(String landmark) {
	this.landmark = landmark;
}
public String getBookedService() {
	return bookedService;
}
public void setBookedService(String bookedService) {
	this.bookedService = bookedService;
}
public String getRejection() {
	return rejection;
}
public void setRejection(String rejection) {
	this.rejection = rejection;
}

}
