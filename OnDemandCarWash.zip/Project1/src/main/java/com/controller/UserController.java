package com.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bean.AdminBean;
import com.bean.BookingDetails;
import com.bean.SearchService;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.service.ServiceDao;
import com.validate.Validate;

@Controller
public class UserController {

	@Autowired
	private ServiceDao service;

	@Autowired
	private Validate validate;

	@ModelAttribute("index")
	public UserBean userBean() {
		return new UserBean();
	}

	@ModelAttribute("aindex")
	public AdminBean adminBean() {
		return new AdminBean();
	}

	@ModelAttribute("vindex")
	public VendorBean vendorBean() {
		return new VendorBean();
	}
	@ModelAttribute("search")
	public SearchService searchservice() {
		return new SearchService();
	}
	@ModelAttribute("bookdetails")
	public BookingDetails bookingdetails() {
		return new BookingDetails();
	}
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String showIndexpage(@ModelAttribute("index") UserBean index) {

		return "Homepage";

	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String User(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Index";

	}

	@RequestMapping(value = "/submitlogin", method = RequestMethod.POST)
	public String LoginValidation(@ModelAttribute("search") SearchService searchService,@Valid @ModelAttribute("index") UserBean index, BindingResult result,Model m) {
		validate.userpassworderror(index, result);
		if (service.userloginvalidate(index)) {
			if(service.useralreadybooked(index)) 
			{
				if(service.userbookingstatus(index)) 
				{
				service.fetchuserbookingdetails(index);
				return "BillPayment";
				}
				else if(service.userpendingstatus(index))
				{
					searchService.setRejection("your booking request is still pending login after few more minutes");
					service.fetchuserdetails(index);
					m.addAttribute("userindex", index);
					List<SearchService> list = null;
					m.addAttribute("searchList", list);
					m.addAttribute("searchservice", searchService);
					return "Login";
				}
				else {
					searchService.setRejection("sorry,your request has been rejected please select another car wash service");
					service.fetchuserdetails(index);
					m.addAttribute("userindex", index);
					List<SearchService> list = null;
					m.addAttribute("searchList", list);
					m.addAttribute("searchservice", searchService);
					return "Login";
				}
				
			}
			else {
				service.fetchuserdetails(index);
				m.addAttribute("userindex", index);
				List<SearchService> list = null;
				m.addAttribute("searchList", list);
				return "Login";
			}
			
		}
		else if (result.hasErrors()) {
			return "Index";
		}
		return "Index";

	}

	@RequestMapping(value = "/submitsignup", method = RequestMethod.POST)
	public String RegistrationPageDisplay(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Registration";
	}

	@RequestMapping(value = "/submitregistration", method = RequestMethod.POST)
	public String RegistrationValidations(@Valid @ModelAttribute("index") UserBean index, BindingResult result) {

		validate.validate(index, result);
		if (result.hasErrors()) {
			return "Registration";
		} else if (service.userinsertvalues(index) > 0) {
			return "Index";
		}
		return "Registration";
	}

	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String Admin(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		return "AdminIndex";

	}

	@RequestMapping(value = "/submitadminlogin", method = RequestMethod.POST)
	public String AdminLoginValidation(@ModelAttribute("aindex") AdminBean aindex, BindingResult result,Model m) {
		validate.adminpassworderror(aindex, result);
		if (result.hasErrors()) {
			return "AdminIndex";
		}
		if (service.adminloginvalidate(aindex)) {
			List<AdminBean> list = null;
			m.addAttribute("vendorslist", list);
			return "AdminHomePage";
		}
		return "AdminIndex";

	}

	@RequestMapping(value = "/submitadminsignup", method = RequestMethod.POST)
	public String AdminRegistrationPageDisplay(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		return "AdminRegistration";
	}
	
	@RequestMapping(value = "/submitadminregistration", method = RequestMethod.POST)
	public String AdminRegistrationValidations(@Valid @ModelAttribute("aindex") AdminBean aindex,
			BindingResult result) {

		validate.validate1(aindex, result);
		if (result.hasErrors()) {
			return "AdminRegistration";
		} else if (service.admininsertvalues(aindex) > 0) {
			return "AdminIndex";
		}
		return "AdminRegistration";
	}
	@RequestMapping(value = "/vendorsapprovallist", method = RequestMethod.POST)
	public String Getvendorslist(@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("aindex") AdminBean aindex, BindingResult result,Model m) {
		List<VendorBean> vendorslist=service.getVendorslist(vindex);
		m.addAttribute("vendorslist", vendorslist);
		return "AdminHomePage";
	}
	@RequestMapping(value = "/approvevendors", method = RequestMethod.POST)
	public String Approvevendorslist(@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("aindex") AdminBean aindex, BindingResult result,Model m,@RequestParam(value="vendor",defaultValue = "0") String selectedvendor) {
		String[] vendors=selectedvendor.split(",");
		for(String vendor:vendors) {
			vindex.setVendorId(vendor);
			if(service.updatestatus(vindex)>0) {
				
			}
		}
		return "xyz";
	}
	@RequestMapping(value = "/vendor", method = RequestMethod.POST)
	public String Vendor(@ModelAttribute("vindex") VendorBean vindex, BindingResult result) {
		return "VendorIndex";
	}

	@RequestMapping(value = "/submitvendorlogin", method = RequestMethod.POST)
	public String VendorLoginValidation(@ModelAttribute("vindex") VendorBean vindex, BindingResult result, Model m) {
		validate.vendorpassworderror(vindex, result);
		if(result.hasErrors())
		{
			return "VendorIndex";
		}
		if (service.vendorloginvalidate(vindex)) 
		{
			service.washingservicecheck(vindex);
			service.fetchvendordetails(vindex);
			m.addAttribute("vendorindex", vindex);
			return "VendorHomePage";
		}
		return "VendorIndex";

	}

	@RequestMapping(value = "/submitvendorsignup", method = RequestMethod.POST)
	public String VendorRegistrationPageDisplay(@ModelAttribute("vindex") VendorBean vindex, BindingResult result) {
		return "VendorRegistration";
	}

	@RequestMapping(value = "/submitvendorregistration", method = RequestMethod.POST)
	public String VendorRegistrationValidations(@Valid @ModelAttribute("vindex") VendorBean vindex,BindingResult result) {
		validate.vendor(vindex, result);
		if (result.hasErrors()) {
			return "VendorRegistration";
		} else if (service.vendorinsertvalues(vindex) > 0) {
			return "VendorIndex";
		}
		return "VendorRegistration";
	}
	@RequestMapping(value = "/ServiceCenterDetails", method = RequestMethod.POST)
	public String vendorWashingServiceDetailsUpdate(@ModelAttribute("vindex") VendorBean vindex,BindingResult result,Model m) {
		if(service.vendorservicecheck(vindex))
		{
			if(service.updateServiceDetails(vindex)>0)
			{
				service.fetchvendordetails(vindex);
				m.addAttribute("vindex", vindex);
				return "VendorHomePage";
			}
		}
		else {
		if(service.insertServiceDetails(vindex)>0)
		{
			service.fetchvendordetails(vindex);
			m.addAttribute("vindex", vindex);
			return "VendorHomePage";
		}
		}
		return "Login";
	}
	@RequestMapping(value = "/Updatepersonaldetails", method = RequestMethod.POST)
	public String vendorDetailsUpdate(@ModelAttribute("vindex") VendorBean vindex,BindingResult result,Model m) {
		if(service.updateServiceDetails(vindex)>0)
		{
			service.fetchvendordetails(vindex);
			m.addAttribute("vindex", vindex);
			return "VendorHomePage";
		}
		return "Login";
	}
	@RequestMapping(value = "/searchdisplay", method = RequestMethod.POST)
	public String SearchDisplay(@ModelAttribute("userindex") UserBean userindex,@ModelAttribute("search") SearchService searchService,BindingResult result,Model m) {
		List<VendorBean> list=service.searchResults(searchService);
		m.addAttribute("searchList", list);
		return "Login";
	}
	@RequestMapping(value = "/deletedetails", method = RequestMethod.POST)
	public String Deletevendorservice(@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("search") SearchService searchService,BindingResult result,Model m,@RequestParam(value="vendorid",defaultValue = "0") String vendorId) {
		vindex.setVendorId(vendorId);
		if(service.deletevendorwashingservice(vindex)>0)
		{
			service.washingservicecheck(vindex);
			service.fetchvendordetails(vindex);
			m.addAttribute("vendorindex", vindex);	
			return "VendorHomePage";
		}
		return "xyz";
	}
	@RequestMapping(value = "/bookservice", method = RequestMethod.POST)
	public String GetDetails(@ModelAttribute("index") UserBean index,@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,Model m,@RequestParam(value="vendor",defaultValue = "0") String selectedcenter) {
		vindex.setVendorId(selectedcenter);
		bookdetails.setVendorId(selectedcenter);
		service.washingservicecheck(vindex);
		m.addAttribute("bookservice", vindex);
		m.addAttribute("bookdetails", bookdetails);
		return "BookWashService";
		
	}
	@RequestMapping(value = "/selectservices", method = RequestMethod.POST)
	public String BookcarServices(@ModelAttribute("index") UserBean index,@ModelAttribute("vindex") VendorBean vindex,@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,Model m,@RequestParam(value="slots",defaultValue = "0") String timeslot,@RequestParam(value="types",defaultValue = "0") String washtype) {
		bookdetails.setTimeSlot(timeslot);
		String washTypes=washtype.replaceAll("[^a-zA-Z]", "");
		bookdetails.setCarwashType(washTypes);
		validate.slotcheck(bookdetails, result);
		if(result.hasErrors())
		{
			vindex.setVendorId(bookdetails.getVendorId());
			bookdetails.setVendorId(bookdetails.getVendorId());
			service.washingservicecheck(vindex);
			m.addAttribute("bookservice", vindex);
			m.addAttribute("bookdetails", bookdetails);
			return "BookWashService";
		}
		if(service.userloginvalidate(index))
		{
			service.fetchuserdetails(index);
			bookdetails.setUserId(index.getEmail());
			String bill=washtype.replaceAll("[^0-9]", "");
			String washtypes=washtype.replaceAll("[^a-zA-Z]", "");
			bookdetails.setTimeSlot(timeslot);
			bookdetails.setCarwashType(washtypes);
			bookdetails.setCarwashBill(bill);
			if(service.insertbookingdetails(bookdetails)>0) {
				return "xyz";
			}
		}
		return "BookWashService";
	}
	@RequestMapping(value = "/gotogateway", method = RequestMethod.POST)
	public String gotoGateway(@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,@RequestParam(value="userid",defaultValue = "0") String userid,@RequestParam(value="billamount",defaultValue = "0") String billamount,Model m) {
		bookdetails.setUserId(userid);
		bookdetails.setCarwashBill(billamount);
		m.addAttribute("bookdetails", bookdetails);
		return "PaymentGateWay";
	}
	@RequestMapping(value = "/paybill" ,method = RequestMethod.POST)
	public String Payment(@ModelAttribute("bookdetails") BookingDetails bookdetails,BindingResult result,@RequestParam(value="userid") String userid) {
		String userId=userid.substring(0, userid.length()-1);
		bookdetails.setUserId(userId);
		if(service.updatebillingstatus(bookdetails)>0) {
		return "xyz";
		}
		return "PaymentGateWay";
	}
	
	@RequestMapping(value = "/approveuserservice", method = RequestMethod.POST)
	public String ApproveServices(@ModelAttribute("vindex") VendorBean vindex, BindingResult result,@RequestParam(value="vendorid") String vendorid,Model m) {
		vindex.setVendorId(vendorid);
		List<BookingDetails> list = null;
		List<VendorBean> vendorslist=null;
		m.addAttribute("bookingdetails", list);
		m.addAttribute("vendordetails", vendorslist);
		return "BookedServiceDetails";
	}
	@RequestMapping(value = "/userbookedservicedetails", method = RequestMethod.POST)
	public String UserDetails(@ModelAttribute("vindex") VendorBean vindex, BindingResult result,@RequestParam(value="vendorid") String vendorid,Model m) {
		vindex.setVendorId(vendorid);
		List<VendorBean> list=service.userbookingapproval(vindex);
		m.addAttribute("bookingdetails", list);
		return "BookedServiceDetails";
	}
	@RequestMapping(value = "/userapproval", method = RequestMethod.POST)
	public String ApprovalStatus(@ModelAttribute("bookdetails") BookingDetails bookdetails,@ModelAttribute("vindex") VendorBean vindex, BindingResult result,@RequestParam(value="vendorid") String vendorid,Model m,@RequestParam(value="userapproval") String userapproveorreject,@RequestParam(value="approvedorrejection") String approveorreject) {
		vindex.setVendorId(vendorid);
		String[] users=userapproveorreject.split(",");
		bookdetails.setBookingStatus(approveorreject);
		for(String user:users)
		{
			bookdetails.setUserId(user);
			if(service.userapproval(bookdetails)>0) {
				bookdetails.setExample(user);
			}
		}
		return "xyz";
	}
	@RequestMapping(value = "/getvendors", method = RequestMethod.POST)
	public String getVendorsforReallocating(@ModelAttribute("vindex") VendorBean vindex, BindingResult result,Model m,@RequestParam(value="vendorid") String vendorid) {
		vindex.setVendorId(vendorid);
		List<VendorBean> list=service.userbookingapproval(vindex);
		List<VendorBean> vendorslist=service.getVendorslist(vindex);
		m.addAttribute("bookingdetails", list);
		m.addAttribute("vendordetails", vendorslist);
		return "BookedServiceDetails";
	}
	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public String Logout(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Homepage";
	}
	
	@RequestMapping(value = "/forgetpassword", method = RequestMethod.POST)
	public String Forgotpassword(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Forgotpassword";

	}
	
}