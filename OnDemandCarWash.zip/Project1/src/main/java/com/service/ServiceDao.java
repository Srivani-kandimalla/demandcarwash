package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;
import com.bean.AdminBean;
import com.bean.BookingDetails;
import com.bean.SearchService;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.connection.Dao;

@Service
public class ServiceDao {

	public int userinsertvalues(UserBean bean) {
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into usertable values(?,?,?,?,?)");
			ps.setString(1, bean.getFirstName());
			ps.setString(2, bean.getLast_name());
			ps.setString(3, bean.getContact_Number());
			ps.setString(4, bean.getEmail());
			ps.setString(5, bean.getPassword());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean userloginvalidate(UserBean bean) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from usertable where email=? and password=?");
			ps.setString(1, bean.getEmail());
			ps.setString(2, bean.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public void fetchuserdetails(UserBean bean) {
		// TODO Auto-generated method stub
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from usertable where email=?");
			ps.setString(1, bean.getEmail());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				bean.setFirstName(rs.getString("first_name"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean adminloginvalidate(AdminBean aindex) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from admin where email=? and password=?");
			ps.setString(1, aindex.getEmail());
			ps.setString(2, aindex.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public int admininsertvalues(AdminBean aindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into admin values(?,?,?,?,?)");
			ps.setString(1, aindex.getFirst_Name());

			ps.setString(2, aindex.getLast_name());
			ps.setString(3, aindex.getContact_Number());
			ps.setString(4, aindex.getEmail());
			ps.setString(5, aindex.getPassword());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean vendorloginvalidate(VendorBean vindex) {
		// TODO Auto-generated method stub

		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_id=? and password=?");
			ps.setString(1, vindex.getVendorId());
			ps.setString(2, vindex.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public int vendorinsertvalues(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into vendor values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, vindex.getFirstName());
			ps.setString(2, vindex.getLastName());
			ps.setString(5, vindex.getContactNumber());
			ps.setString(6, vindex.getVendorId());
			ps.setString(7, vindex.getPassword());
			ps.setString(3, vindex.getAge());
			ps.setString(4, vindex.getGender());
			ps.setString(8, "empty");
			ps.setString(9, "empty");
			ps.setString(10, "empty");
			ps.setString(11, "pending");
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean userduplicatecheck(UserBean bean) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from usertable where email=?");
			ps.setString(1, bean.getEmail());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public boolean adminduplicatecheck(AdminBean bean) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from admin where email=?");
			ps.setString(1, bean.getEmail());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public boolean vendorduplicatecheck(VendorBean vendorbean) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_id=?");
			ps.setString(1, vendorbean.getVendorId());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public void washingservicecheck(VendorBean vindex) {
		// TODO Auto-generated method stub
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from servicedetails where Vendor_Id=?");
			ps.setString(1, vindex.getVendorId());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				vindex.setWashingCenterName(rs.getString("washingCenterName"));
				vindex.setWashType1(rs.getString("washingCenterType"));
				vindex.setVendorId(rs.getString("Vendor_Id"));
				vindex.setWashingCenterTime(rs.getString("washingCenterTime"));
				vindex.setWashingCenterContact(rs.getString("washingCenterContact"));
				vindex.setWashingCenterAddress(rs.getString("washingCenterAddress"));
				vindex.setLandmark(rs.getString("landmark"));
				vindex.setWashType2(rs.getString("washType2"));
				vindex.setWashType3(rs.getString("washType3"));
				vindex.setGooglelocation(rs.getString("googlelocation"));
				vindex.setTimeslotOne(rs.getString("timeslotOne"));
				vindex.setTimeslotTwo(rs.getString("timeslotTwo"));
				vindex.setTimeslotThree(rs.getString("timeslotThree"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insertServiceDetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into servicedetails values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, vindex.getVendorId());
			ps.setString(2, vindex.getWashingCenterName());
			ps.setString(3, vindex.getWashType1());
			ps.setString(4, vindex.getWashingCenterTime());
			ps.setString(5, vindex.getWashingCenterContact());
			ps.setString(6, vindex.getWashingCenterAddress());
			ps.setString(7, vindex.getWashType2());
			ps.setString(8, vindex.getWashType3());
			ps.setString(9, vindex.getLandmark());
			ps.setString(10, vindex.getGoogleLocation());
			ps.setString(11, vindex.getTimeslotOne());
			ps.setString(12, vindex.getTimeslotTwo());
			ps.setString(13, vindex.getTimeslotThree());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public void fetchvendordetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_id=?");
			ps.setString(1, vindex.getVendorId());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				vindex.setFirstName((rs.getString("first_name")));
				vindex.setLastName(("last_name"));
				vindex.setAge((rs.getString("age")));
				vindex.setGender((rs.getString("gender")));
				vindex.setContactNumber((rs.getString("contact_number")));
				vindex.setLandlineNumber((rs.getString("Alternate_Number")));
				vindex.setAddress((rs.getString("Address")));
				vindex.setEmailId((rs.getString("Email_Id")));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int updateVendorDetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("update vendor set first_name=?,last_name=?,age=?,gender=?,contact_number=?,Alternate_Number=?,Address=?,Email_Id=? where vendor_id=?");
			ps.setString(1, vindex.getFirstName());
			ps.setString(2, vindex.getLastName());
			ps.setString(3, vindex.getAge());
			ps.setString(4, vindex.getGender());
			ps.setString(5, vindex.getContactNumber());
			ps.setString(6, vindex.getLandlineNumber());
			ps.setString(7, vindex.getAddress());
			ps.setString(8, vindex.getEmailId());
			ps.setString(9, vindex.getVendorId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean vendorservicecheck(VendorBean vindex) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from servicedetails where Vendor_Id=?");
			ps.setString(1, vindex.getVendorId());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public List<VendorBean> getVendorslist(VendorBean vindex) {
		// TODO Auto-generated method stub
		List<VendorBean> vendorlist=new ArrayList<>();
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from servicedetails");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				VendorBean vendors=new VendorBean();
				vendors.setWashingCenterName(rs.getString("washingCenterName"));
				vendors.setWashType1(rs.getString("washingCenterType"));
				vendors.setVendorId(rs.getString("Vendor_Id"));
				vendors.setWashingCenterTime(rs.getString("washingCenterTime"));
				vendors.setWashingCenterContact(rs.getString("washingCenterContact"));
				vendors.setWashingCenterAddress(rs.getString("washingCenterAddress"));
				vendors.setLandmark(rs.getString("landmark"));
				vendorlist.add(vendors);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vendorlist;
	}
	public int updateServiceDetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("update servicedetails set washingCenterName=?,washingCenterType=?,washingCenterTime=?,washingCenterContact=?,washingCenterAddress=?,washType2=?,washType3=?,landmark=?,googlelocation=?,timeslotOne=?,timeslotTwo=?,timeslotThree=? where Vendor_Id=?");
			ps.setString(1, vindex.getWashingCenterName());
			ps.setString(2, vindex.getWashType1());
			ps.setString(3, vindex.getWashingCenterTime());
			ps.setString(4, vindex.getWashingCenterContact());
			ps.setString(5, vindex.getWashingCenterAddress());
			ps.setString(6, vindex.getWashType2());
			ps.setString(7, vindex.getWashType3());
			ps.setString(8, vindex.getLandmark());
			ps.setString(9, vindex.getGoogleLocation());
			ps.setString(10, vindex.getTimeslotOne());
			ps.setString(11, vindex.getTimeslotTwo());
			ps.setString(12, vindex.getTimeslotThree());
			ps.setString(13, vindex.getVendorId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public List<VendorBean> searchResults(SearchService searchService) {
		// TODO Auto-generated method stub
		List<VendorBean> list = new ArrayList<>();
		String centerName = searchService.getCenterName();
		String centerType = searchService.getCenterType();
		String landmark = searchService.getLandmark();
		if (centerName != "empty" && centerType.equals("empty") && landmark.equals("empty")) {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where washingCenterName=?");
				ps.setString(1, searchService.getCenterName());
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean centerNamePriority = new VendorBean();
					centerNamePriority.setWashingCenterName(rs.getString("washingCenterName"));
					centerNamePriority.setWashType1(rs.getString("washingCenterType"));
					centerNamePriority.setVendorId(rs.getString("Vendor_Id"));
					centerNamePriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					centerNamePriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					centerNamePriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					centerNamePriority.setLandmark(rs.getString("landmark"));
					centerNamePriority.setWashType2(rs.getString("washType2"));
					centerNamePriority.setWashType3(rs.getString("washType3"));
					centerNamePriority.setGooglelocation(rs.getString("googlelocation"));
					centerNamePriority.setTimeslotOne(rs.getString("timeslotOne"));
					centerNamePriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					centerNamePriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(centerNamePriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (centerType != "empty" && centerName.equals("empty") && landmark.equals("empty")) {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where washingCenterType like ? OR washType2 like ? OR washType3 like ?");
				ps.setString(1, "%" + centerType +"%");
				ps.setString(2, "%" + centerType +"%");
				ps.setString(3, "%" + centerType +"%");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean centerTypePriority = new VendorBean();
					centerTypePriority.setWashingCenterName(rs.getString("washingCenterName"));
					centerTypePriority.setWashType1(rs.getString("washingCenterType"));
					centerTypePriority.setVendorId(rs.getString("Vendor_Id"));
					centerTypePriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					centerTypePriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					centerTypePriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					centerTypePriority.setLandmark(rs.getString("landmark"));
					centerTypePriority.setWashType2(rs.getString("washType2"));
					centerTypePriority.setWashType3(rs.getString("washType3"));
					centerTypePriority.setGooglelocation(rs.getString("googlelocation"));
					centerTypePriority.setTimeslotOne(rs.getString("timeslotOne"));
					centerTypePriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					centerTypePriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(centerTypePriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (landmark != "empty" && centerName.equals("empty") && centerType.equals("empty")) {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where landmark=?");
				ps.setString(1, searchService.getLandmark());
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean landmarkPriority = new VendorBean();
					landmarkPriority.setWashingCenterName(rs.getString("washingCenterName"));
					landmarkPriority.setWashType1(rs.getString("washingCenterType"));
					landmarkPriority.setVendorId(rs.getString("Vendor_Id"));
					landmarkPriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					landmarkPriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					landmarkPriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					landmarkPriority.setLandmark(rs.getString("landmark"));
					landmarkPriority.setWashType2(rs.getString("washType2"));
					landmarkPriority.setWashType3(rs.getString("washType3"));
					landmarkPriority.setGooglelocation(rs.getString("googlelocation"));
					landmarkPriority.setTimeslotOne(rs.getString("timeslotOne"));
					landmarkPriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					landmarkPriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(landmarkPriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (landmark != "empty" && centerType!="empty" && centerName.equals("empty")) {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where landmark=? AND washingCenterType like ? OR washType2 like ? OR washType3 like ?");
				ps.setString(1, searchService.getLandmark());
				ps.setString(2,"%" + centerType +"%");
				ps.setString(3, "%" + centerType +"%");
				ps.setString(4, "%" + centerType +"%");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean landmarkAndCenterTypePriority = new VendorBean();
					landmarkAndCenterTypePriority.setWashingCenterName(rs.getString("washingCenterName"));
					landmarkAndCenterTypePriority.setWashType1(rs.getString("washingCenterType"));
					landmarkAndCenterTypePriority.setVendorId(rs.getString("Vendor_Id"));
					landmarkAndCenterTypePriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					landmarkAndCenterTypePriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					landmarkAndCenterTypePriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					landmarkAndCenterTypePriority.setLandmark(rs.getString("landmark"));
					landmarkAndCenterTypePriority.setWashType2(rs.getString("washType2"));
					landmarkAndCenterTypePriority.setWashType3(rs.getString("washType3"));
					landmarkAndCenterTypePriority.setGooglelocation(rs.getString("googlelocation"));
					landmarkAndCenterTypePriority.setTimeslotOne(rs.getString("timeslotOne"));
					landmarkAndCenterTypePriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					landmarkAndCenterTypePriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(landmarkAndCenterTypePriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (landmark != "empty" && centerName!="empty" && centerType.equals("empty")) {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where landmark=? AND washingCenterName=?");
				ps.setString(1, searchService.getLandmark());
				ps.setString(2,searchService.getCenterName());
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean landmarkAndCenterNamePriority = new VendorBean();
					landmarkAndCenterNamePriority.setWashingCenterName(rs.getString("washingCenterName"));
					landmarkAndCenterNamePriority.setWashType1(rs.getString("washingCenterType"));
					landmarkAndCenterNamePriority.setVendorId(rs.getString("Vendor_Id"));
					landmarkAndCenterNamePriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					landmarkAndCenterNamePriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					landmarkAndCenterNamePriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					landmarkAndCenterNamePriority.setLandmark(rs.getString("landmark"));
					landmarkAndCenterNamePriority.setWashType2(rs.getString("washType2"));
					landmarkAndCenterNamePriority.setWashType3(rs.getString("washType3"));
					landmarkAndCenterNamePriority.setGooglelocation(rs.getString("googlelocation"));
					landmarkAndCenterNamePriority.setTimeslotOne(rs.getString("timeslotOne"));
					landmarkAndCenterNamePriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					landmarkAndCenterNamePriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(landmarkAndCenterNamePriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if ( centerType!= "empty" && centerName!="empty" && landmark.equals("empty")) {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where washingCenterName=?  AND washingCenterType like ? OR washType2 like ? OR washType3 like ?");
				ps.setString(1,searchService.getCenterName());
				ps.setString(2, "%" + centerType +"%");
				ps.setString(3, "%" + centerType +"%");
				ps.setString(4, "%" + centerType +"%");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean CenterNameAndTypePriority = new VendorBean();
					CenterNameAndTypePriority.setWashingCenterName(rs.getString("washingCenterName"));
					CenterNameAndTypePriority.setWashType1(rs.getString("washingCenterType"));
					CenterNameAndTypePriority.setVendorId(rs.getString("Vendor_Id"));
					CenterNameAndTypePriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					CenterNameAndTypePriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					CenterNameAndTypePriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					CenterNameAndTypePriority.setLandmark(rs.getString("landmark"));
					CenterNameAndTypePriority.setWashType2(rs.getString("washType2"));
					CenterNameAndTypePriority.setWashType3(rs.getString("washType3"));
					CenterNameAndTypePriority.setGooglelocation(rs.getString("googlelocation"));
					CenterNameAndTypePriority.setTimeslotOne(rs.getString("timeslotOne"));
					CenterNameAndTypePriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					CenterNameAndTypePriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(CenterNameAndTypePriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if ( centerType!= "empty" && centerName!="empty" && landmark!="empty") {
			try {
				Connection con = Dao.getConnection();
				PreparedStatement ps = con.prepareStatement("select * from servicedetails where washingCenterName=? and landmark=? AND washingCenterType like ? OR washType2 like ? OR washType3 like ?");
				ps.setString(1,searchService.getCenterName());
				ps.setString(2, searchService.getLandmark());
				ps.setString(3, "%" + centerType +"%");
				ps.setString(4, "%" + centerType +"%");
				ps.setString(5, "%" + centerType +"%");
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					VendorBean CenterNameAndTypePriority = new VendorBean();
					CenterNameAndTypePriority.setWashingCenterName(rs.getString("washingCenterName"));
					CenterNameAndTypePriority.setWashType1(rs.getString("washingCenterType"));
					CenterNameAndTypePriority.setVendorId(rs.getString("Vendor_Id"));
					CenterNameAndTypePriority.setWashingCenterTime(rs.getString("washingCenterTime"));
					CenterNameAndTypePriority.setWashingCenterContact(rs.getString("washingCenterContact"));
					CenterNameAndTypePriority.setWashingCenterAddress(rs.getString("washingCenterAddress"));
					CenterNameAndTypePriority.setLandmark(rs.getString("landmark"));
					CenterNameAndTypePriority.setWashType2(rs.getString("washType2"));
					CenterNameAndTypePriority.setWashType3(rs.getString("washType3"));
					CenterNameAndTypePriority.setGooglelocation(rs.getString("googlelocation"));
					CenterNameAndTypePriority.setTimeslotOne(rs.getString("timeslotOne"));
					CenterNameAndTypePriority.setTimeslotTwo(rs.getString("timeslotTwo"));
					CenterNameAndTypePriority.setTimeslotThree(rs.getString("timeslotThree"));
					list.add(CenterNameAndTypePriority);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public int insertbookingdetails(BookingDetails bookdetails) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into bookingdetails values(?,?,?,?,?,?,?,?)");
			ps.setString(1, bookdetails.getUserId());
			ps.setString(2, bookdetails.getVendorId());
			ps.setString(3, bookdetails.getTimeSlot());
			ps.setString(4, bookdetails.getCarwashType());
			ps.setString(5, bookdetails.getCarwashBill());
			ps.setString(6, bookdetails.getBookingStatus());
			ps.setString(7, bookdetails.getUserAddress());
			ps.setString(8,bookdetails.getBillstatus());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
		
	}

	public boolean slotbookingcheck(BookingDetails bookingdetails) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from bookingdetails where vendorId=? AND timeSlot=? AND carwashType=?");
			ps.setString(1, bookingdetails.getVendorId());
			ps.setString(2, bookingdetails.getTimeSlot());
			ps.setString(3, bookingdetails.getCarwashType());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
		}

	public boolean useralreadybooked(UserBean index) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from bookingdetails where userId=?");
			ps.setString(1, index.getEmail());
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				index.setBillstatus(rs.getString("billstatus"));
			}
			if(index.getBillstatus().equals("notpaid")) {
				status=true;
			}
			else {
				status=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return status;
		
	}

	public void fetchuserbookingdetails( UserBean index) {
		// TODO Auto-generated method stub
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from bookingdetails where userId=?");
			ps.setString(1, index.getEmail());
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				index.setCarwashBill(rs.getString("carwashBill"));
				index.setCarwashType(rs.getString("carWashType"));
				index.setTimeSlot(rs.getString("timeSlot"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public int updatebillingstatus(BookingDetails bookdetails) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("update bookingdetails set billstatus=?,timeSlot=? where userId=? AND billstatus=?");
			ps.setString(1, "paid");
			ps.setString(2, "0");
			ps.setString(3, bookdetails.getUserId());
			ps.setString(4, "notpaid");
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
		
	}

	public List<VendorBean> userbookingapproval(VendorBean vindex) {
		// TODO Auto-generated method stub
		List<VendorBean> list = new ArrayList<>();
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from bookingdetails where vendorId=? and bookingStatus=?");
			ps.setString(1, vindex.getVendorId());
			ps.setString(2, "pending");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				VendorBean vendorindex=new VendorBean();
				vendorindex.setBookedusers(rs.getString("userId"));
				vendorindex.setBookedtimeslots(rs.getString("timeSlot"));
				list.add(vendorindex);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int userapproval(BookingDetails bookdetails) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("update bookingdetails set bookingStatus=? where userId=?");
			ps.setString(1, bookdetails.getBookingStatus());
			ps.setString(2, bookdetails.getUserId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean userbookingstatus(UserBean index) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from bookingdetails where userId=? and billstatus=?");
			ps.setString(1, index.getEmail());
			ps.setString(2, "notpaid");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				index.setBookingstatus(rs.getString("bookingStatus"));
			}
			if(index.getBookingstatus().equals("approved")){
				status=true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public boolean userpendingstatus(@Valid UserBean index) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from bookingdetails where userId=? and billstatus=?");
			ps.setString(1, index.getEmail());
			ps.setString(2, "notpaid");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				index.setBookingstatus(rs.getString("bookingStatus"));
			}
			if(index.getBookingstatus().equals("pending")){
				status=true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public int updatestatus(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("update vendor set status=? where vendor_id=?");
			ps.setString(1, "approved");
			ps.setString(2, vindex.getVendorId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public int deletevendorwashingservice(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i=0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("DELETE FROM servicedetails where Vendor_Id=?");
			ps.setString(1, vindex.getVendorId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

}
