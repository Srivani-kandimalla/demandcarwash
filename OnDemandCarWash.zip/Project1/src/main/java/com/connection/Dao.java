package com.connection;

import java.sql.*;

public class Dao {

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cts", "root", "Rhscp*143");
		return con;
	}

}
