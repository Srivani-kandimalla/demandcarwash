package com.example.Project1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.bean.AdminBean;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.service.ServiceDao;

@SpringBootTest
class Project1ApplicationTests {
	ServiceDao servicedao = new ServiceDao();
	UserBean testuser = new UserBean();
	AdminBean testadmin = new AdminBean();
	VendorBean testvendor=new VendorBean();
	@Test
	public void userloginValidcheckIfEmailAndPasswordareCorrect() {
		testuser.setEmail("srivani@gmail.com");
		testuser.setPassword("srivani");
		assertTrue(servicedao.userloginvalidate(testuser));
	}

	@Test
	public void userloginValidcheckIfEmailAndPasswordareNotCorrect() {
		testuser.setEmail("abc@gmail.com");
		testuser.setPassword("abc");
		assertFalse(servicedao.userloginvalidate(testuser));
	}
	@Test
	public void userloginValidcheckIfEmailIsNotCorrect() {
		testuser.setEmail("abc@gmail.com");
		testuser.setPassword("srivani");
		assertFalse(servicedao.userloginvalidate(testuser));
	}
	@Test
	public void userloginValidcheckIfPasswordIsNotCorrect() {
		testuser.setEmail("srivani@gmail.com");
		testuser.setPassword("abc");
		assertFalse(servicedao.userloginvalidate(testuser));
	}
	@Test
	public void adminloginValidcheckIfEmailAndPasswordareCorrect() {
		testadmin.setEmail("sanjana@gmail.com");
		testadmin.setPassword("sanjana");
		assertTrue(servicedao.adminloginvalidate(testadmin));
	}
	@Test
	public void adminloginValidcheckIfEmailAndPasswordareNotCorrect() {
		testadmin.setEmail("abc@gmail.com");
		testadmin.setPassword("abc");
		assertFalse(servicedao.adminloginvalidate(testadmin));
	}
	@Test
	public void adminloginValidcheckIfEmailIsNotCorrect() {
		testadmin.setEmail("abc@gmail.com");
		testadmin.setPassword("sanjana");
		assertFalse(servicedao.adminloginvalidate(testadmin));
	}
	@Test
	public void adminloginValidcheckIfPasswordIsNotCorrect() {
		testadmin.setEmail("sanjana@gmail.com");
		testadmin.setPassword("abc");
		assertFalse(servicedao.adminloginvalidate(testadmin));
	}
	@Test
	public void vendorloginValidcheckIfVendoridAndPasswordareCorrect() {
		testvendor.setVendorId("srivani_123");
		testvendor.setPassword("srivani");
		assertTrue(servicedao.vendorloginvalidate(testvendor));
	}
	@Test
	public void vendorloginValidcheckIfVendoridAndPasswordareNotCorrect() {
		testvendor.setVendorId("abc_123");
		testvendor.setPassword("abc");
		assertFalse(servicedao.vendorloginvalidate(testvendor));
	}
	@Test
	public void vendorloginValidcheckIfVendoridIsNotCorrect() {
		testvendor.setVendorId("abc_123");
		testvendor.setPassword("srivani");
		assertFalse(servicedao.vendorloginvalidate(testvendor));
	}
	@Test
	public void vendorloginValidcheckIfPasswordIsNotCorrect() {
		testvendor.setVendorId("srivani_123");
		testvendor.setPassword("abc");
		assertFalse(servicedao.vendorloginvalidate(testvendor));
	}
	@Test
	public void userRegistrationValidCheck()
	{
		testuser.setFirstName("subhashini");
		testuser.setContact_Number("9874563212");
		testuser.setEmail("subhashini@gmail.com");
		testuser.setPassword("password");
		assertEquals(1,servicedao.userinsertvalues(testuser));
	}
	@Test
	public void adminRegistrationValidCheck()
	{
		testadmin.setFirst_Name("subhashini");
		testadmin.setContact_Number("9874563212");
		testadmin.setEmail("subhashini@gmail.com");
		testadmin.setPassword("subhashini");
		assertEquals(1,servicedao.admininsertvalues(testadmin));
	}
	@Test
	public void vendorRegistrationValidCheck()
	{
		testvendor.setFirstName("subhashini");
		testvendor.setVendorId("subhashini_123");
		testvendor.setContactNumber("9874563212");
		testvendor.setPassword("subhashini");
		testvendor.setAge("21");
		testvendor.setGender("female");
		assertEquals(1,servicedao.admininsertvalues(testadmin));
	}
}
